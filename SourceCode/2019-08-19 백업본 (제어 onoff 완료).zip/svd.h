#ifndef _SVD_H
#define _SVD_H


void svd(int m, int n, double **a, double **p, double *d, double **q);

#endif